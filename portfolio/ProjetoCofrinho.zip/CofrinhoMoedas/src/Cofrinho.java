import java.util.ArrayList;
import java.util.List;

public class Cofrinho {
    // Lista para armazenar as moedas (usa polimorfismo - pode guardar qualquer subtipo de Moeda)
    private List<Moeda> listaMoedas = new ArrayList<>();
    
    // Adiciona uma moeda ao cofrinho
    public void adicionar(Moeda moeda) {
        listaMoedas.add(moeda);
        System.out.println("Moeda adicionada com sucesso!");
    }
    
    // Remove uma moeda do cofrinho (compara pelo valor)
    public void remover(Moeda moeda) {
        // Percorre a lista para encontrar moeda com mesmo valor
        for (Moeda m : listaMoedas) {
            if (m.getValor() == moeda.getValor() && m.getClass().equals(moeda.getClass())) {
                listaMoedas.remove(m);
                System.out.println("Moeda removida com sucesso!");
                return;
            }
        }
        System.out.println("Moeda não encontrada no cofrinho.");
    }
    
    // Lista todas as moedas no cofrinho
    public void listagemMoedas() {
        if (listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio!");
            return;
        }
        
        System.out.println("----- Moedas no Cofrinho -----");
        for (Moeda moeda : listaMoedas) {
            moeda.info(); // Polimorfismo - chama o método info() específico de cada moeda
        }
    }
    
    // Calcula o total convertido para Real
    public double totalConvertido() {
        double total = 0;
        for (Moeda moeda : listaMoedas) {
            total += moeda.converter(); // Polimorfismo - chama o converter() específico
        }
        return total;
    }
}



//Desenvolvido por Thalles Daniel