public class Dolar extends Moeda {
    // Construtor
    public Dolar(double valor) {
        super(valor);
    }
    
    // Mostra informações específicas do Dólar
    @Override
    public void info() {
        System.out.println("Dólar - Valor: " + valor);
    }
    
    // Converte dólar para real (cotação fixa para simplificar)
    @Override
    public double converter() {
        return valor * 5.0; // Considerando 1 dólar = R$5,00
    }
}

//Desenvolvido por Thalles Daniel