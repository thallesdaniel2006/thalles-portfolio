public class Real extends Moeda {
    // Construtor
    public Real(double valor) {
        super(valor);
    }
    
    // Mostra informações específicas do Real
    @Override
    public void info() {
        System.out.println("Real - Valor: " + valor);
    }
    
    // Para o Real
    @Override
    public double converter() {
        return valor;
    }
}

//Desenvolvido por Thalles Daniel1
