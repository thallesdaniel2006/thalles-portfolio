import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // Cria scanner para entrada de dados
        Cofrinho cofrinho = new Cofrinho();  // Instancia um novo cofrinho
        
        int opcao;  // Variável para armazenar a opção do menu
        do {
            exibirMenu();  // Mostra o menu de opções
            opcao = scanner.nextInt();  // Lê a opção do usuário
            
            // Switch para tratar cada opção do menu
            switch (opcao) {
                case 1:  // Adicionar moeda
                    adicionarMoeda(scanner, cofrinho);
                    break;
                case 2:  // Remover moeda
                    removerMoeda(scanner, cofrinho);
                    break;
                case 3:  // Listar moedas
                    cofrinho.listagemMoedas();
                    break;
                case 4:  // Calcular total convertido
                    double total = cofrinho.totalConvertido();
                    System.out.printf("Total convertido para Real: R$ %.2f\n", total);
                    break;
                case 5:  // Sair do programa
                    System.out.println("Encerrando o programa...");
                    break;
                default:  // Opção inválida
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 5);  // Repete até usuário escolher sair
        
        scanner.close();  // Fecha o scanner
    }
    
    // Método para exibir o menu principal
    private static void exibirMenu() {
        System.out.println("\n----- COFRINHO DE MOEDAS -----");
        System.out.println("\n----- THALLES DANIEL -----");
        System.out.println();
        System.out.println("1 - Adicionar moeda");
        System.out.println("2 - Remover moeda");
        System.out.println("3 - Listar moedas");
        System.out.println("4 - Calcular total convertido para Real");
        System.out.println("5 - Sair");
        System.out.println();
        System.out.print("Escolha uma opção: ");
    }
    
    // Método para adicionar uma moeda ao cofrinho
    private static void adicionarMoeda(Scanner scanner, Cofrinho cofrinho) {
        System.out.println("\nEscolha o tipo de moeda:");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        System.out.print("Opção: ");
        int tipo = scanner.nextInt();  // Lê o tipo de moeda
        
        System.out.print("Digite o valor: ");
        double valor = scanner.nextDouble();  // Lê o valor da moeda
        
        Moeda moeda;
        // Cria a moeda conforme o tipo escolhido
        switch (tipo) {
            case 1:
                moeda = new Real(valor);
                break;
            case 2:
                moeda = new Dolar(valor);
                break;
            case 3:
                moeda = new Euro(valor);
                break;
            default:
                System.out.println("Tipo de moeda inválido!");
                return;  // Sai se o tipo for inválido
        }
        
        cofrinho.adicionar(moeda);  // Adiciona a moeda ao cofrinho
    }
    
    // Método para remover uma moeda do cofrinho
    private static void removerMoeda(Scanner scanner, Cofrinho cofrinho) {
        System.out.println("\nEscolha o tipo de moeda a remover:");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        System.out.print("Opção: ");
        int tipo = scanner.nextInt();  // Lê o tipo de moeda
        
        System.out.print("Digite o valor: ");
        double valor = scanner.nextDouble();  // Lê o valor da moeda
        
        Moeda moeda;
        // Cria a moeda conforme o tipo escolhido
        switch (tipo) {
            case 1:
                moeda = new Real(valor);
                break;
            case 2:
                moeda = new Dolar(valor);
                break;
            case 3:
                moeda = new Euro(valor);
                break;
            default:
                System.out.println("Tipo de moeda inválido!");
                return;  // Sai se o tipo for inválido
        }
        
        cofrinho.remover(moeda);  // Remove a moeda do cofrinho
    }
}

//Desenvolvido por Thalles Daniel