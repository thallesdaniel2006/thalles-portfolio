// Classe abstrata que representa uma moeda genérica
public abstract class Moeda {
    protected double valor; // Valor da moeda
    
    // Construtor
    public Moeda(double valor) {
        this.valor = valor;
    }
    
    // Método abstrato para mostrar informações da moeda
    public abstract void info();
    
    // Método abstrato para converter o valor para Real
    public abstract double converter();
    
    // Getter para o valor 
    public double getValor() {
        return valor;
    }
}

//Desenvolvido por Thalles Daniel