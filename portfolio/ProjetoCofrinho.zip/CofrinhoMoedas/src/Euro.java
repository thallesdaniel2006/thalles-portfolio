public class Euro extends Moeda {
    // Construtor
    public Euro(double valor) {
        super(valor);
    }
    

    @Override
    public void info() {
        System.out.println("Euro - Valor: " + valor);
    }
    
    // Converte euro para real 
    @Override
    public double converter() {
        return valor * 5.5; // Considerando 1 euro 5,50
    }
}

//Desenvolvido por Thalles Daniel